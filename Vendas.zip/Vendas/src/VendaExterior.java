public class VendaExterior extends Venda {

  public VendaExterior(String c, String n, double v) {
    super(c, n, v);
    setImposto(0);
    setFrete(100);
  }

  public String toString() {
    return "----\nVENDA: EXTERIOR\n" + super.toString();
  }
}
